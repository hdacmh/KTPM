export const USER_SERVER = "/api/client";
export const PRODUCT_SEVRER = "/api/item";
