import React, { Component } from "react";

class Not_found extends Component {
  render() {
    return (
      <div>
        <h1 style={{ textAlign: "center" }}>This page wasn't found</h1>
      </div>
    );
  }
}

export default Not_found;
