Cách cài đặt đồ án:
B1: Clone Project về và mở trên Visual Studio Code
B2: Mở termiral và chạy lệnh "npm install"
B3: Mở thêm 1 cửa số Termiral mới và chạy lệnh "cd client" sau đó chạy tiếp lệnh "npm install"
Cuối cùng: sau khi cài đặt xong chạy lệnh "npm run dev" để thực thi dự án.
