// dev.js - don't commit this

module.exports = {
  // googleClientID: '422769475641-9ag65aoq2u38s49ri4lnlco2nb3i8i2j.apps.googleusercontent.com',
  // googleClientSecret: 'chhrgW1d5GQBd6ea-ZQcTZ4K',
  googleClientID: '176306854563-cg3j6i3fp7nf84k2fh7ejbcggv3p5pm6.apps.googleusercontent.com',
  googleClientSecret: 'HtP37S9fVLPDGjKprzzHyxnW',
  facebookClientID: '2233754246902632',
  facebookClientSecret: '2c4343233cdb50edb57787be12dab493',
  cookieKey: 'pkpkshrtsprsgfngtmbynmtb',
  mongoURI: 'mongodb://localhost/bazaarDB',
  stripePublishableKey: 'pk_test_51M7bYzE0FWZxEukkmjkxfqp7Ewyh9ZCiyRGyaxMyt0OSgAsXEJRgBbV19772EjY5g5OzcAWbqBMrdcifuneuOtTt00lxQXQFjB',
  stripeSecretKey: 'sk_test_bdtZXcczztegIi7sk_test_51M7bYzE0FWZxEukkp7K2XHpocTTdYffHTPRVflVS4K0ltn9u1ay0Q5flyAJQYdUDxN8F9yUuJfu3FLbC3DZKUSsL003DzbmNqV',
};
